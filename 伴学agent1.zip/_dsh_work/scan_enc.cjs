const fs = require("fs");
const path = require("path");
const root = "E:\\人工智能+创新大赛\\js";
const markers = ["\u5b66\u751f", "\u77e5\u8bc6\u70b9", "\u6570\u636e", "\u8bca\u65ad"]; // 学生 知识点 数据 诊断
function walk(d, out) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p, out); else if (e.name.endsWith(".js")) out.push(p);
  }
  return out;
}
const files = walk(root, []);
for (const f of files) {
  const s = fs.readFileSync(f, "utf8");
  const hits = markers.reduce((n, m) => n + (s.split(m).length - 1), 0);
  const bad = (s.match(/\uFFFD/g) || []).length;
  if (s.length > 3000) console.log(path.relative(root, f).padEnd(38), "len=" + String(s.length).padEnd(7), "cnMarkers=" + String(hits).padEnd(5), "replacement=" + bad);
}
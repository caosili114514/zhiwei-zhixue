/**
 * 数据层自检（Node 环境，不依赖浏览器）
 * 用法：node _dsh_work/check_data.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const ROOT = path.resolve(import.meta.dirname, '..');

/* --- 最小浏览器环境 --- */
const listeners = {};
globalThis.window = globalThis;
globalThis.localStorage = {
  _data: {},
  getItem(k) { return this._data[k] === undefined ? null : this._data[k]; },
  setItem(k, v) { this._data[k] = String(v); },
  removeItem(k) { delete this._data[k]; }
};
globalThis.document = {
  readyState: 'loading',
  addEventListener(type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
  removeEventListener() {},
  querySelector() { return null; },
  querySelectorAll() { return []; },
  getElementById() { return null; },
  createElement() { return { style: {}, classList: { add() {}, remove() {} }, appendChild() {}, setAttribute() {} }; },
  body: { style: {}, appendChild() {}, removeChild() {} }
};
globalThis.URL = globalThis.URL || class {};
globalThis.Blob = globalThis.Blob || class {};

const FILES = [
  'js/core/html.js',
  'js/core/pages.js',
  'js/data/seed.js',
  'js/services/parser.js',
  'js/services/grader.js',
  'js/services/diagnosis.js',
  'js/services/selectors.js',
  'js/services/assistant.js',
  'js/services/io.js',
  'js/core/store.js',
  'js/core/ui.js',
  'js/core/charts.js'
];

for (const rel of FILES) {
  const code = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  try {
    vm.runInThisContext(code, { filename: rel });
  } catch (err) {
    console.error('加载失败:', rel, err.message);
    process.exit(1);
  }
}

const ZWZ = globalThis.ZWZ;
const store = ZWZ.store.init();
const state = store.state;
const sel = ZWZ.sel;
const diag = ZWZ.diagnosis;

const out = [];
const log = (...a) => out.push(a.join(' '));

log('=== 基础数据 ===');
log('学生数:', state.classes[0].studentIds.length,
  '| 题目数:', state.questions.length,
  '| 试卷数:', state.papers.length,
  '| 任务数:', state.tasks.length,
  '| 作答记录:', state.answers.length);
const statusCount = ZWZ.grader.countByStatus(state);
log('判分状态分布:', JSON.stringify(statusCount));

log('\n=== 演示学生 s1 林以安 · 诊断 ===');
const s1 = sel.diagnostics(state, { studentId: 's1' });
s1.forEach((d) => {
  log(`${d.kpName.padEnd(16, ' ')} | ${d.performanceLabel.padEnd(8, ' ')} | ${d.statusLabel.padEnd(6, ' ')} | 记录 ${d.evidence.records} 可判读 ${d.evidence.judged} | 错 ${d.evidence.wrong} | ${d.evidence.coverageText} | ${d.errorTypes.map((e) => e.label).join('/') || '-'}`);
});
log('s1 stats:', JSON.stringify(sel.studentOverview(state, 's1').stats));

log('\n=== 班级知识点分析 ===');
sel.kpAnalysis(state, 'c1').forEach((r) => {
  log(`${r.kpName.padEnd(16, ' ')} | 覆盖率 ${(r.coverage * 100).toFixed(0)}% | 掌握率 ${r.masteryRate === null ? '—' : (r.masteryRate * 100).toFixed(0) + '%'} | 仍需巩固 ${r.weakCount} | 正确率 ${r.accuracy === null ? '—' : (r.accuracy * 100).toFixed(0) + '%'} | 待复核 ${r.pendingCount} | 错误类型 ${r.errorTypes.map((e) => e.label + e.count).join('/') || '-'}`);
});

log('\n=== 班级概览 ===');
const ov = sel.classOverview(state, 'c1');
log('学生:', ov.studentCount, '活跃:', ov.activeStudents, '正确率:', ov.accuracy === null ? '—' : (ov.accuracy * 100).toFixed(0) + '%',
  '提示率:', ov.hintRate === null ? '—' : (ov.hintRate * 100).toFixed(0) + '%',
  '待复核批阅:', ov.pendingGrades, '待确认诊断:', ov.pendingDiagnoses);
log('错误类型分布:', ov.errorTypes.map((e) => `${e.label}×${e.count}`).join('、'));
log('趋势:', JSON.stringify(ov.trend.xLabels), JSON.stringify(ov.trend.series.map((s) => s.points)));

log('\n=== 学生助手 ===');
const reply = ZWZ.assistant.studentReply(state, { studentId: 's1', questionId: 'q5', level: 2 });
log('level2:', reply.messages[0].title, '|', reply.messages[0].body.slice(0, 40) + '...');
const reply4 = ZWZ.assistant.studentReply(state, { studentId: 's1', questionId: 'q5', level: 4 });
log('level4:', reply4.messages[0].title, '|', reply4.messages[0].body.slice(0, 40) + '...');

log('\n=== 教师助手 ===');
['本班目前最需要关注哪些知识点？', '错误类型集中在哪？', '林以安最近学习情况怎么样？', '这批数据的覆盖情况够不够支撑结论？', '随便问点什么'].forEach((q) => {
  const r = ZWZ.assistant.teacherReply(state, { classId: 'c1', message: q });
  log(`Q: ${q}\n  intent=${r.intent} cards=${r.cards.length} | ${r.cards[0] ? r.cards[0].title : r.reply.slice(0, 30)}`);
});

log('\n=== 导出（CSV 生成） ===');
const csv = ZWZ.io.toCSV(
  [{ key: 'a', label: '姓名' }, { key: 'b', label: '知识点' }],
  [{ a: '林以安', b: '有理数的加减运算' }]
);
log('CSV 行数:', csv.split('\r\n').length, '| 含 BOM:', csv.startsWith('\uFEFF'));

log('\n=== 提交作答闭环 ===');
const before = sel.diagnostics(state, { studentId: 's1' }).filter((d) => d.kpId === 'kp4')[0];
const submitted = store.actions.submitAnswer({ studentId: 's1', taskId: 't3', questionId: 'q23', rawAnswer: '1', hintLevels: [1, 2] });
const after = sel.diagnostics(state, { studentId: 's1' }).filter((d) => d.kpId === 'kp4')[0];
log('提交前:', before.performanceLabel, before.statusLabel, before.evidence.records, '条');
log('提交后:', after.performanceLabel, after.statusLabel, after.evidence.records, '条 | 判分:', submitted.answer.gradeStatus, submitted.answer.score);
log('新证据:', after.evidence.quotes.slice(-1)[0]);

log('\n=== 数据一致性检查 ===');
let problems = [];
const qIds = new Set(state.questions.map((q) => q.id));
state.answers.forEach((a) => {
  if (!qIds.has(a.questionId)) problems.push('作答引用不存在的题目: ' + a.questionId);
  if (a.score === undefined) problems.push('未判分: ' + a.id);
});
state.tasks.forEach((t) => {
  t.questionIds.forEach((qid) => { if (!qIds.has(qid)) problems.push('任务引用不存在的题目: ' + qid); });
});
sel.classStudents(state, 'c1').forEach((st) => {
  const d = sel.diagnostics(state, { studentId: st.id });
  if (d.length !== state.knowledgePoints.length) problems.push(st.name + ' 诊断条目数异常: ' + d.length);
});
log('问题数:', problems.length);
problems.slice(0, 10).forEach((p) => log('  -', p));

console.log(out.join('\n'));

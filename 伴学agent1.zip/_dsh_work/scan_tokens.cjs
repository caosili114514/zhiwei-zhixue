const fs = require("fs");
const path = require("path");
const root = "E:\\人工智能+创新大赛";
const skip = new Set(["_dsh_work", "tests", "node_modules"]);
function walk(d, out) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (skip.has(e.name)) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(js|css|html|md)$/.test(e.name)) out.push(p);
  }
  return out;
}
const files = walk(root, []);
const patterns = [
  ["\u9875\u9762\u5f00\u53d1\u4e2d", "页面开发中"],
  ["TODO", "TODO"],
  ["FIXME", "FIXME"],
  ["console.log", "console.log"],
  ["\u5f85\u5b9e\u73b0", "待实现"],
  ["\u5360\u4f4d", "占位"]
];
let total = 0;
for (const f of files) {
  const s = fs.readFileSync(f, "utf8");
  for (const [pat, label] of patterns) {
    let idx = s.indexOf(pat);
    while (idx >= 0) {
      total++;
      const line = s.slice(0, idx).split("\n").length;
      console.log(path.relative(root, f) + ":" + line + "  [" + label + "]  " + s.slice(idx, Math.min(idx + 60, s.length)).replace(/\s+/g, " "));
      idx = s.indexOf(pat, idx + 1);
      if (total > 60) break;
    }
  }
}
console.log("---- total hits:", total, "files:", files.length);